#!/usr/bin/env python3
# -*- coding: utf-8 -*-

### YOUR CODE HERE for part 1e
import torch
import torch.nn as nn
import torch.nn.functional as F

class CNN(nn.Module):
    def __init__(self, c_embed_size:int = 50, max_word:int = 21, kernel:int = 5, filters:int = None):
        """ 
        Init CNN which is a 1-D cnn.
        @param c_embed_size (int): embedding size of char (dimensionality)
        @param kernel: kernel size, also called window size
        @param filters: number of filters, should be embed_size of word
        """

        # Conv1d: https://pytorch.org/docs/stable/nn.html?highlight=conv1d#torch.nn.functional.conv1d
        # MaxPool1d
        super(CNN, self).__init__()
        self.c_embed_size = c_embed_size
        self.max_word = max_word
        self.kernel = kernel
        self.filters = filters

        self.conv1d = nn.Conv1d(in_channels=c_embed_size,
                                out_channels=filters,
                                kernel_size=kernel,
                                bias=True)
       
        self.maxpool = nn.MaxPool1d(kernel_size=max_word - kernel + 1)

    def forward(self, X_reshaped: torch.Tensor) -> torch.Tensor:
        """
        map from X_reshaped to X_conv_out
        @param X_reshaped (Tensor): Tensor of char-level embedding with shape (max_sentence_length, 
                                    batch_size, e_char, m_word), where e_char = embed_size of char, 
                                    m_word = max_word_length.
        @return X_conv_out (Tensor): Tensor of word-level embedding with shape (max_sentence_length,
                                    batch_size)
        """

        X_conv = self.conv1d(X_reshaped)
        X_conv_out = self.maxpool(F.relu(X_conv))

        return torch.squeeze(X_conv_out, -1)

### END YOUR CODE

